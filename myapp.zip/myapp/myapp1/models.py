from django.db import models
#from . models import Destination
# Create your models here.
#admin.site.register(Destination)